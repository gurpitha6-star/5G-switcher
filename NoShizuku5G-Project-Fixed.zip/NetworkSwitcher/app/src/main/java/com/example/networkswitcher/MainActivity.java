package com.example.networkswitcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private void openNetworkSettings(String desiredMode) {
        Toast.makeText(this,
                "Ab Network settings me Preferred network type me " + desiredMode + " chunein.",
                Toast.LENGTH_LONG).show();
        Intent intent = new Intent("android.settings.NETWORK_OPERATOR_SETTINGS");
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
            } catch (ActivityNotFoundException ignored) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(this);
        title.setText("5G / 4G Network Helper");
        title.setTextSize(25);
        title.setTextColor(0xFF102A43);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Shizuku aur Root ki zaroorat nahi. Android security ke kaaran app khud se network mode nahi badal sakta. Button dabane par phone ki network settings khulengi; wahan mode select karein.");
        info.setTextSize(16);
        info.setTextColor(0xFF334E68);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.setMargins(0, 24, 0, 28);
        root.addView(info, ip);

        Button fiveG = new Button(this);
        fiveG.setText("5G MODE SETTINGS KHOLEN");
        fiveG.setAllCaps(false);
        fiveG.setOnClickListener(v -> openNetworkSettings("5G / 5G preferred"));
        root.addView(fiveG, new LinearLayout.LayoutParams(-1, -2));

        Button lte = new Button(this);
        lte.setText("4G / LTE MODE SETTINGS KHOLEN");
        lte.setAllCaps(false);
        lte.setOnClickListener(v -> openNetworkSettings("LTE / 4G only"));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, 14, 0, 0);
        root.addView(lte, bp);

        TextView note = new TextView(this);
        note.setText("Note: Aapke Motorola/Jio software me Preferred network type ka option alag jagah ho sakta hai ya carrier ne chhupaya ho sakta hai.");
        note.setTextSize(13);
        note.setTextColor(0xFF627D98);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, 30, 0, 0);
        root.addView(note, np);
        setContentView(root);
    }
}
