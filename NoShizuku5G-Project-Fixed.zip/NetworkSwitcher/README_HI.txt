5G / 4G Network Helper (No Shizuku)

Yeh project bina Shizuku aur bina Root ke APK banata hai.

IMPORTANT LIMITATION:
Android normal third-party apps ko bina privileged system permission ke preferred network mode (5G/LTE) seedha badalne nahi deta. Isliye is app ke buttons Network Operator Settings kholte hain. Settings me agar Preferred network type option mile to manually 5G ya LTE select karein. Motorola/Jio firmware ke hisaab se option chhupa ya unavailable ho sakta hai.

APK build:
1. Is ZIP ko extract karke GitHub repository me files upload karein.
2. GitHub > Actions > Build Android APK workflow run/complete hone dein.
3. Successful run ke Artifacts me NoShizuku5G-debug-apk download karein.
4. ZIP extract karke app-debug.apk install karein.
