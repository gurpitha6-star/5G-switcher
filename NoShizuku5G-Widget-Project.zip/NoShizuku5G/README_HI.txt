5G / 4G Network Helper - No Shizuku, No Root

Is project me app aur Home Screen widget dono hain.
Widget add karne ke liye: Home Screen par khaali jagah long-press > Widgets > 5G / 4G Switcher.

Zaroori seema:
Android 16 par ek normal third-party APK bina privileged system permission, root, ya ADB/Shizuku ke preferred network mode ko khud se 5G/LTE par set nahi kar sakta. Isliye app aur widget ke 5G/LTE buttons Jio/network settings page kholte hain. Wahan Preferred network type me aapko manually 5G ya LTE select karna hoga. Motorola ke software ke hisaab se khulne wala page alag ho sakta hai; exact Preferred network type popup direct khulne ki guarantee nahi hai.

GitHub Actions se build:
1. ZIP extract karke uske andar ka poora NoShizuku5G folder repository ke root me upload karein.
2. GitHub > Actions me Build Android APK workflow kholen.
3. Green success ke baad artifact NoShizuku5G-debug-apk download karein.
