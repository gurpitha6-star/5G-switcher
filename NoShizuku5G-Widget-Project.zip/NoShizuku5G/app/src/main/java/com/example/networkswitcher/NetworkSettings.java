package com.example.networkswitcher;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Toast;

public final class NetworkSettings {
    private NetworkSettings() {}
    public static void open(Context context, String mode) {
        Toast.makeText(context,
                "Preferred network type me " + mode + " manually select karein.",
                Toast.LENGTH_LONG).show();
        Intent[] choices = new Intent[] {
                new Intent("android.settings.NETWORK_OPERATOR_SETTINGS"),
                new Intent(Settings.ACTION_WIRELESS_SETTINGS),
                new Intent(Settings.ACTION_SETTINGS)
        };
        for (Intent intent : choices) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(intent);
                return;
            } catch (ActivityNotFoundException ignored) { }
        }
    }
}
