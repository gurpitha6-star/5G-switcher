package com.example.networkswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF5F7FA);

        TextView title = new TextView(this);
        title.setText("5G / 4G Network Helper");
        title.setTextSize(25); title.setTextColor(0xFF102A43); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("Shizuku aur Root ki zaroorat nahi. Android 16 me normal APK khud se network mode select nahi kar sakta. Ye buttons Jio network settings kholenge; Preferred network type me 5G ya LTE manually chunein.");
        info.setTextSize(16); info.setTextColor(0xFF334E68); info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.setMargins(0, 24, 0, 28);
        root.addView(info, ip);

        Button fiveG = new Button(this); fiveG.setText("5G SETTINGS KHOLEN"); fiveG.setAllCaps(false);
        fiveG.setOnClickListener(v -> NetworkSettings.open(this, "5G (recommended)"));
        root.addView(fiveG, new LinearLayout.LayoutParams(-1, -2));

        Button lte = new Button(this); lte.setText("4G / LTE SETTINGS KHOLEN"); lte.setAllCaps(false);
        lte.setOnClickListener(v -> NetworkSettings.open(this, "LTE"));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.setMargins(0, 14, 0, 0);
        root.addView(lte, bp);

        TextView note = new TextView(this);
        note.setText("Home Screen widget bhi available hai. Widget ke 5G aur LTE buttons bhi isi network settings page ko kholenge; automatic selection supported nahi hai.");
        note.setTextSize(13); note.setTextColor(0xFF627D98); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.setMargins(0, 30, 0, 0);
        root.addView(note, np);
        setContentView(root);
    }
}
