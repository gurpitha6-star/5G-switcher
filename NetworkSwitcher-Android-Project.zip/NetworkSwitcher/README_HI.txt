5G SWITCHER — Android source project (prototype)

IMPORTANT:
- Yeh abhi APK nahi hai; yeh Android Studio/AndroidIDE project source hai.
- Is environment mein Android SDK/Gradle build tools maujood nahi the, isliye APK compile/test nahi kiya ja saka.
- Motorola Edge 50 Neo / Android 16 par command ka kaam karna guaranteed nahi hai.
- 5G mode ka matlab 5G (NR) aur LTE dono allowed; phone/modem phir decide karta hai 5G connect karna hai ya nahi. Yeh 5G force/guarantee nahi karta.
- LTE mode mask LTE-only karta hai. Jio calling/VoLTE behaviour handset firmware par depend karega.
- Default SIM slot 0 (SIM 1). SIM 2 ke liye NetworkWidget.java mein SLOT = 1 karein.
- Shizuku ADB mode mein har reboot ke baad Wireless debugging se dobara start karna pad sakta hai.

Build:
1. AndroidIDE ya Android Studio mein project folder open karein.
2. Gradle sync hone dein (internet required; AGP 8.7.3, compileSdk 35, Shizuku API 13.1.5).
3. Build > Build APK(s) / assembleDebug.
4. APK app/build/outputs/apk/debug/app-debug.apk mein milega.
5. Install, Shizuku ko Wireless debugging se start karein, app open karke permission grant karein.
6. Home Screen long-press > Widgets > 5G Switcher add karein.

The widget button alternates between “5G allowed” and “LTE only”. Use at your own discretion.
