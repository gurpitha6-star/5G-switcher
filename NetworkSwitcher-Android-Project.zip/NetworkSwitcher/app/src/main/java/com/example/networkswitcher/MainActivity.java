package com.example.networkswitcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 1001;
    private final Shizuku.OnRequestPermissionResultListener listener = (requestCode, grantResult) -> {
        Toast.makeText(this, grantResult == PackageManager.PERMISSION_GRANTED ? "Shizuku permission mil gayi" : "Permission nahi mili", Toast.LENGTH_LONG).show();
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Shizuku.addRequestPermissionResultListener(listener);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28, 40, 28, 24); box.setGravity(Gravity.CENTER);
        TextView title = new TextView(this); title.setText("5G Switcher"); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        TextView info = new TextView(this); info.setText("Widget ko Home Screen par add karein. Pehle Shizuku ko Wireless debugging se start karein, phir neeche permission dein.\n\n5G mode = LTE + NR allowed (network 5G choose kar sakta hai). LTE mode = LTE only. SIM 1 default hai."); info.setTextSize(16); info.setPadding(0, 24, 0, 24);
        Button perm = new Button(this); perm.setText("Grant Shizuku permission"); perm.setOnClickListener(v -> {
            if (!Shizuku.pingBinder()) Toast.makeText(this, "Pehle Shizuku app mein Start karein", Toast.LENGTH_LONG).show();
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) Toast.makeText(this, "Permission pehle se granted hai", Toast.LENGTH_SHORT).show();
            else Shizuku.requestPermission(REQUEST_CODE);
        });
        box.addView(title); box.addView(info); box.addView(perm); setContentView(box);
    }
    @Override protected void onDestroy() { Shizuku.removeRequestPermissionResultListener(listener); super.onDestroy(); }
}
