package com.example.networkswitcher;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import android.widget.Toast;
import rikka.shizuku.Shizuku;

public class NetworkWidget extends AppWidgetProvider {
    static final String PREFS = "network_switcher";
    static final String KEY_LTE = "lte_only";
    static final String ACTION_TOGGLE = "com.example.networkswitcher.TOGGLE";
    static final int SLOT = 0; // SIM 1 by default. Change to 1 for SIM 2.
    static final String LTE_ONLY_MASK = "10000000000000"; // bit 13: LTE only
    static final String ALL_TYPES_MASK = "111111111111111111111"; // bits 0..20: includes LTE + NR

    @Override public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) update(c, mgr, id);
    }

    static void update(Context c, AppWidgetManager mgr, int id) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        boolean lte = p.getBoolean(KEY_LTE, false);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_network);
        v.setTextViewText(R.id.widget_button, lte ? "LTE ONLY · TAP FOR 5G" : "5G ALLOWED · TAP FOR LTE");
        v.setInt(R.id.widget_button, "setBackgroundColor", lte ? 0xFF245A91 : 0xFF176B45);
        Intent i = new Intent(c, NetworkWidget.class).setAction(ACTION_TOGGLE);
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_button, pi);
        mgr.updateAppWidget(id, v);
    }

    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (!ACTION_TOGGLE.equals(intent.getAction())) return;
        if (!Shizuku.pingBinder()) {
            Toast.makeText(c, "Shizuku start karein", Toast.LENGTH_LONG).show(); return;
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(c, "App kholkar Shizuku permission dein", Toast.LENGTH_LONG).show();
            Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(open); return;
        }
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        boolean nextLte = !p.getBoolean(KEY_LTE, false);
        String mask = nextLte ? LTE_ONLY_MASK : ALL_TYPES_MASK;
        new Thread(() -> {
            try {
                String cmd = "cmd phone set-allowed-network-types-for-users -s " + SLOT + " " + mask;
                // Shizuku 13.1.x keeps newProcess private; invoke it reflectively for
                // compatibility with this API version. Newer versions recommend UserService.
                java.lang.reflect.Method method = Shizuku.class.getDeclaredMethod(
                        "newProcess", String[].class, String[].class, String.class);
                method.setAccessible(true);
                Process proc = (Process) method.invoke(null,
                        new String[]{"sh", "-c", cmd}, null, null);
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream();
                try (java.io.InputStream in = proc.getInputStream(); java.io.InputStream err = proc.getErrorStream()) {
                    byte[] buf = new byte[1024]; int n;
                    while ((n = in.read(buf)) > 0) output.write(buf, 0, n);
                    while ((n = err.read(buf)) > 0) output.write(buf, 0, n);
                }
                int code = proc.waitFor();
                String result = output.toString("UTF-8").trim();
                android.util.Log.i("5GSwitcher", "Command exit=" + code + " output=" + result);
                new android.os.Handler(c.getMainLooper()).post(() -> Toast.makeText(c, code == 0 ? (nextLte ? "LTE-only command sent" : "5G allowed command sent") : "Switch failed: " + result, Toast.LENGTH_LONG).show());
                if (code == 0) {
                    p.edit().putBoolean(KEY_LTE, nextLte).apply();
                    AppWidgetManager mgr = AppWidgetManager.getInstance(c);
                    int[] ids = mgr.getAppWidgetIds(new ComponentName(c, NetworkWidget.class));
                    for (int id : ids) update(c, mgr, id);
                }
                proc.destroy();
            } catch (Throwable e) {
                android.util.Log.e("5GSwitcher", "Network switch failed", e);
                new android.os.Handler(c.getMainLooper()).post(() -> Toast.makeText(c, "Switch error: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
