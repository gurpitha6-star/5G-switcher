5G / 4G Network Helper - V3

Build:
- Is ZIP ko extract karein.
- GitHub repository ke root me NetworkSwitcher folder ke ANDAR ki files upload karein
  (app, build.gradle, settings.gradle, gradle.properties, .github).
- Ya project folder ko repository root banayein.
- GitHub Actions me Build Android APK workflow run karein.
- Artifact NoShizuku5G-debug-apk download karein.

Features:
- Main app me 5G aur LTE Settings shortcuts.
- Home Screen widget me 5G Settings aur 4G/LTE Settings buttons.
- Shizuku aur root nahi chahiye.

Important:
Android ka public API Preferred network type ke internal 5G/LTE radio-button dialog ko
directly open karne ka supported intent nahi deta. App pehle Mobile Network Settings,
phir Network Operator Settings try karega. Motorola Android 16 par exact page/popup
ka result OEM software par depend karega. User ko 5G ya LTE manually select karna hoga.
