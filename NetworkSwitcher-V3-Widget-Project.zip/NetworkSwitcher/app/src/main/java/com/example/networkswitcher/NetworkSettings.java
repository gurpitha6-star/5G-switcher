package com.example.networkswitcher;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Toast;

public final class NetworkSettings {
    private NetworkSettings() {}

    public static void open(Context context, String mode) {
        Toast.makeText(context,
                mode + " select karne ke liye Preferred network type me option chunein.",
                Toast.LENGTH_LONG).show();

        // Android/OEM versions expose different Settings entry points.
        // There is no public Android API for opening the internal radio-button dialog itself.
        Intent[] intents = new Intent[] {
            new Intent("android.settings.MOBILE_NETWORK_SETTINGS"),
            new Intent("android.settings.NETWORK_OPERATOR_SETTINGS"),
            new Intent(Settings.ACTION_WIRELESS_SETTINGS),
            new Intent(Settings.ACTION_SETTINGS)
        };

        for (Intent intent : intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(intent);
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
                // Try the next public Settings entry point.
            }
        }

        Toast.makeText(context, "Network Settings nahi khul payi. Settings app manually kholen.",
                Toast.LENGTH_LONG).show();
    }
}
