package com.example.networkswitcher;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class NetworkWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.network_widget);
            views.setOnClickPendingIntent(R.id.widget_5g, pending(context, "5G", 1));
            views.setOnClickPendingIntent(R.id.widget_lte, pending(context, "LTE", 2));
            manager.updateAppWidget(id, views);
        }
    }

    private PendingIntent pending(Context context, String mode, int requestCode) {
        Intent intent = new Intent(context, NetworkWidgetReceiver.class);
        intent.setAction("com.example.networkswitcher.OPEN_" + mode);
        intent.putExtra("mode", mode);
        return PendingIntent.getBroadcast(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
