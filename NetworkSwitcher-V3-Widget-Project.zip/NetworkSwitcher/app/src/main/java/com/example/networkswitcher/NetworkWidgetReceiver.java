package com.example.networkswitcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NetworkWidgetReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String mode = intent.getStringExtra("mode");
        if (mode == null) mode = "5G";
        NetworkSettings.open(context, mode);
    }
}
