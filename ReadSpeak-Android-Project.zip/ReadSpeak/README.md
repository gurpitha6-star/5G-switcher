# Read & Speak — Android starter project

An Android app starter that lets a learner select a chapter photo, extracts English text with Google ML Kit OCR, and speaks a tapped word using the phone's Text-to-Speech engine. It includes British/American accent selection, slow speech, read-aloud, a simple online English definition lookup, local bookmarks, and locally saved chapters.

## Open and build

1. Install Android Studio (current stable) and the Android SDK Platform 35.
2. Open this `ReadSpeak` folder in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build tools.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- This is a source project, not a prebuilt APK. An Android SDK/Gradle build environment is required to compile it.
- British and American voices depend on which speech voices are installed on the phone. If a voice is missing, install it from Android Settings > Accessibility or System > Text-to-speech output (the exact menu varies by device).
- OCR works on printed text and image quality affects accuracy. Review the extracted text against the page.
- Word definitions are fetched from the Free Dictionary API and therefore require internet access. Photos and extracted chapters are processed/stored locally; the definition lookup sends only the selected word to the dictionary service.
- Saved chapters and bookmarks are stored in the app's private local preferences and are removed if the app data is cleared or the app is uninstalled.
