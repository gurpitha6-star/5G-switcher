package com.readspeak.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ClickableSpan
import android.text.method.LinkMovementMethod
import android.view.View
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var chapterText: TextView
    private lateinit var statusText: TextView
    private lateinit var wordText: TextView
    private lateinit var accentGroup: RadioGroup
    private var chapter = ""
    private var selectedWord = ""
    private var slow = false
    private val prefs by lazy { getSharedPreferences("readspeak", MODE_PRIVATE) }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) extractText(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        chapterText = findViewById(R.id.chapterText)
        statusText = findViewById(R.id.statusText)
        wordText = findViewById(R.id.wordText)
        accentGroup = findViewById(R.id.accentGroup)
        tts = TextToSpeech(this, this)
        accentGroup.setOnCheckedChangeListener { _, _ -> setAccent() }

        findViewById<Button>(R.id.uploadButton).setOnClickListener { pickImage.launch("image/*") }
        findViewById<Button>(R.id.readButton).setOnClickListener {
            if (chapter.isNotBlank()) speak(chapter) else toast("Upload a chapter photo first.")
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener { tts.stop() }
        findViewById<Button>(R.id.slowButton).setOnClickListener {
            slow = !slow
            it as Button
            it.text = if (slow) "Slow voice: On" else "Slow voice: Off"
            tts.setSpeechRate(if (slow) 0.65f else 1.0f)
        }
        findViewById<Button>(R.id.saveButton).setOnClickListener { saveChapter() }
        findViewById<Button>(R.id.bookmarkButton).setOnClickListener { bookmarkWord() }
        findViewById<Button>(R.id.bookmarksButton).setOnClickListener { showBookmarks() }
        findViewById<Button>(R.id.savedButton).setOnClickListener { showSavedChapters() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) setAccent()
        else statusText.text = "Text-to-speech could not start. Check your phone's speech engine."
    }

    private fun setAccent() {
        val locale = if (accentGroup.checkedRadioButtonId == R.id.americanRadio) Locale.US else Locale.UK
        val result = tts.setLanguage(locale)
        tts.setSpeechRate(if (slow) 0.65f else 1.0f)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            statusText.text = "Selected voice is not installed. Install it in Android Text-to-speech settings."
        }
    }

    private fun speak(text: String) {
        setAccent()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "readspeak-${System.currentTimeMillis()}")
    }

    private fun extractText(uri: Uri) {
        statusText.text = "Reading the photo…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener { result ->
                    chapter = result.text.trim()
                    if (chapter.isBlank()) {
                        statusText.text = "No readable text found. Try a clearer, well-lit photo."
                    } else {
                        renderClickableText()
                        statusText.text = "Text extracted. Tap any word to hear it."
                    }
                }
                .addOnFailureListener { error -> statusText.text = "Could not read this photo: ${error.localizedMessage}" }
        } catch (e: Exception) {
            statusText.text = "Could not open this image: ${e.localizedMessage}"
        }
    }

    private fun renderClickableText() {
        val spannable = SpannableString(chapter)
        val regex = Regex("[A-Za-z]+(?:['’-][A-Za-z]+)*")
        regex.findAll(chapter).forEach { match ->
            spannable.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    selectedWord = match.value.trim('’', '\'', '-', '–')
                    wordText.text = "${match.value}  •  Pronunciation playing…\nLooking up English definition…"
                    speak(match.value)
                    lookupDefinition(selectedWord)
                }
            }, match.range.first, match.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        chapterText.text = spannable
        chapterText.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun lookupDefinition(word: String) {
        Thread {
            var meaning = "Definition unavailable. Connect to the internet and try again."
            try {
                val encoded = URLEncoder.encode(word, "UTF-8")
                val connection = (URL("https://api.dictionaryapi.dev/api/v2/entries/en/$encoded").openConnection() as HttpURLConnection)
                connection.connectTimeout = 6000
                connection.readTimeout = 6000
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONArray(body)
                val meanings = arr.getJSONObject(0).optJSONArray("meanings")
                if (meanings != null && meanings.length() > 0) {
                    val defs = meanings.getJSONObject(0).optJSONArray("definitions")
                    if (defs != null && defs.length() > 0) meaning = defs.getJSONObject(0).optString("definition", meaning)
                }
                connection.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { wordText.text = "$word\nEnglish definition: $meaning" }
        }.start()
    }

    private fun bookmarkWord() {
        if (selectedWord.isBlank()) { toast("Tap a word first."); return }
        val old = JSONArray(prefs.getString("bookmarks", "[]"))
        val words = (0 until old.length()).map { old.optString(it) }.toMutableSet()
        words.add(selectedWord)
        val updated = JSONArray()
        words.sorted().forEach { updated.put(it) }
        prefs.edit().putString("bookmarks", updated.toString()).apply()
        toast("Bookmarked: $selectedWord")
    }

    private fun showBookmarks() {
        val arr = JSONArray(prefs.getString("bookmarks", "[]"))
        val list = (0 until arr.length()).map { arr.optString(it) }
        AlertDialog.Builder(this).setTitle("Bookmarked words")
            .setMessage(if (list.isEmpty()) "No bookmarked words yet." else list.joinToString("\n"))
            .setPositiveButton("OK", null).show()
    }

    private fun saveChapter() {
        if (chapter.isBlank()) { toast("Upload a chapter first."); return }
        val arr = JSONArray(prefs.getString("chapters", "[]"))
        arr.put(JSONObject().put("title", "Chapter ${arr.length() + 1}").put("text", chapter))
        prefs.edit().putString("chapters", arr.toString()).apply()
        toast("Chapter saved on this device.")
    }

    private fun showSavedChapters() {
        val arr = JSONArray(prefs.getString("chapters", "[]"))
        if (arr.length() == 0) { toast("No saved chapters yet."); return }
        val titles = Array(arr.length()) { i -> arr.getJSONObject(i).optString("title", "Chapter ${i + 1}") }
        AlertDialog.Builder(this).setTitle("Saved chapters").setItems(titles) { _, which ->
            chapter = arr.getJSONObject(which).optString("text", "")
            renderClickableText()
            statusText.text = "Saved chapter opened. Tap any word to hear it."
        }.setNegativeButton("Close", null).show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
